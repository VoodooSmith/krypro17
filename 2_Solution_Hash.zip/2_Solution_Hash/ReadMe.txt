#################
#				#
#	Hash Setup	#
#				#
#################


Solution Parts
******************************
1)	Text_Hashing.cs


Build Information
******************************
Target-Framework 4.5 (compatible with Apple)


Program structure
******************************
x) Program starts and user has possibility to choose hash algorithm (MD5, SHA256, SHA384, SHA512)
x) According the user input the hash algorithm will be intitiated
x) User has again the possibility to enter arbitrary text
x) String will be converted to byte array 
x) In the next step hash value will be computed
	



